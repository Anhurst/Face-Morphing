Annalise Hurst

My main.ipynb file contains all the code I used to create my results. To use it, open it as a Jupyter notebook and begin running the cells for the assignment. Each part of the assignment is labeled with a functions section (if applicable) and a main section. The main section is where you will enter your image(s) file path(s) and running the cells will perform the calculations and procedures to produce the results to the output file paths specified. Make sure you run all of the cells in order.
